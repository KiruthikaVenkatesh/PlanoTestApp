﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PlanoTestApp.Models
{
    public class GetUserDto
    {
        public long UserId { get; set; }
        public string Language { get; set; }
    }
}
