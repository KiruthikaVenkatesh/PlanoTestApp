﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PlanoTestApp.Models;
using PlanoTestApp.Repositories;

namespace PlanoTestApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {

        private readonly IPlanoTestRepository _planoTestRepository;

        public UserController(IPlanoTestRepository planoTestRepository)
        {
            _planoTestRepository = planoTestRepository;
        }


        //Get User Info
        [HttpPost]
        [Route("GetUser")]
        public JsonResult GetUser(GetUserDto userDto)
        {
            var user =  _planoTestRepository.GetUser(userDto.UserId);

            var response = new 
            {
                FullName = user.FullName,
                Message = "I am a developer from Plano"
            };

            return new JsonResult(response);
                  
        }

        //Add new User 
        [HttpPost]
        [Route("AddUser")]
        public JsonResult AddUser( NewUser userDto)
        {
            var isSuccess = _planoTestRepository.Add(userDto);

            if(isSuccess)
                return new JsonResult(new { isSucessful = isSuccess });
            else
            return new JsonResult(new { isSucessful = isSuccess });

        }
    }
}
