﻿using PlanoTestApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PlanoTestApp.Repositories
{
    public class PlanoTestRepository : IPlanoTestRepository
    {
        public readonly PlanoTestDbContext _planoTestDbContext;
        public PlanoTestRepository(PlanoTestDbContext planoTestDbContext)
        {
            _planoTestDbContext = planoTestDbContext;
        }

        public Users GetUser(long id)
        {
            return _planoTestDbContext.Users
                  .FirstOrDefault(e => e.UserId == id);
        }
        public bool Add(NewUser newUser)
        {
            Users user = new Users { FullName = newUser.FullName, Language = newUser.Language };
            _planoTestDbContext.Users.Add(user);
            var result = _planoTestDbContext.SaveChanges();

            return result > 0;
        }
    }
}
