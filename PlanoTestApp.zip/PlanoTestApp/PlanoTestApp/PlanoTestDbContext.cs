﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
namespace PlanoTestApp
{
    public class PlanoTestDbContext : Microsoft.EntityFrameworkCore.DbContext
    {

        public PlanoTestDbContext(DbContextOptions options)
            : base(options)
        {
        }
        public Microsoft.EntityFrameworkCore.DbSet<Users> Users { get; set; }
    }
}
